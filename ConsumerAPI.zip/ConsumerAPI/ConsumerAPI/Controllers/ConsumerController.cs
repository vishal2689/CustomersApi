﻿using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using ConsumerAPI.Models;

namespace ConsumerAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ConsumerController : ControllerBase
    {
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly string _filePath;
        private Consumers getDataFromJson()
        {
            try
            {
                var json = System.IO.File.ReadAllText(_filePath);
                var consumersJson = JsonConvert.DeserializeObject<Consumers>(json);
                return consumersJson;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private IList<Consumer> getConsumers(Consumers consumersJson, int limit, Name searchParam)
        {
            try
            {
                if (String.IsNullOrEmpty(searchParam.First_Name) || String.IsNullOrEmpty(searchParam.Last_Name))
                {
                    return consumersJson.consumers.Take(limit).ToList();
                }
                else
                {
                    return consumersJson.consumers
                    .Where(s => s.Name.First_Name == searchParam.First_Name || s.Name.Last_Name == searchParam.Last_Name)
                    .Take(limit).ToList();

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private Consumer getConsumer(Consumers consumersJson, int id)
        {
            var consumer = new Consumer();

            try
            {
                consumer = consumersJson.consumers.First(s => s.Id == id);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return consumer;
        }
        public ConsumerController(IHostingEnvironment hostingEnvironment)
        {
            _hostingEnvironment = hostingEnvironment;
            string contentRootPath = _hostingEnvironment.ContentRootPath;
            _filePath = contentRootPath + "/App_Data/Consumer.json";
        }
        // GET api/consumer
        [HttpPost]
        public ActionResult<IEnumerable<string>> Get(int limit, [FromBody]Name searchParam)
        {
            try
            {
                var consumersJson = getDataFromJson();
                var consumers = getConsumers(consumersJson, limit, searchParam);
                return Ok(consumers);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        // GET api/consumer/5
        [HttpGet("{id}")]
        public ActionResult<string> Get(int id)
        {

            try
            {
                var consumersJson = getDataFromJson();
                var consumer = getConsumer(consumersJson, id);
                return Ok(consumer);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        // PUT api/consumer/5
        [HttpPut("{id}")]
        public ActionResult Put(int id, [FromBody] Consumer value)
        {
            try
            {
                var consumersJson = getDataFromJson();
                if (consumersJson.consumers.Where(couns => couns.Id == id).Count() > 0)
                {
                    foreach (var consumer in consumersJson.consumers.Where(couns => couns.Id == id))
                    {
                        consumer.Name = value.Name;
                        consumer.Email = value.Email;
                        consumer.Date_Of_Birth = value.Date_Of_Birth;
                        consumer.Phone_Number = value.Phone_Number;
                    }
                    System.IO.File.WriteAllText(_filePath, JsonConvert.SerializeObject(consumersJson));
                    return Ok("Consumer with Id='" + id + "' is Updated.");

                }
                else
                {
                    return Ok("No Record to update.");
                }


            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        // DELETE api/consumer/5
        [HttpDelete("{id}")]
        public ActionResult Delete(int id)
        {
            try
            {
                var consumersJson = getDataFromJson();
                var consumer = getConsumer(consumersJson, id);
                consumersJson.consumers.Remove(consumer);
                System.IO.File.WriteAllText(_filePath, JsonConvert.SerializeObject(consumersJson));
                return Ok("Consumer with Id='" + consumer.Id + "' is deleted.");
            }
            catch (Exception)
            {
                return BadRequest();
            }

        }
    }
}
