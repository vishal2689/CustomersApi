﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ConsumerAPI.Models
{
    public class Consumers
    {
        public IList<Consumer> consumers { get; set; }
    }
}
